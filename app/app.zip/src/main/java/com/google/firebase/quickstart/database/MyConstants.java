package com.google.firebase.quickstart.database;

public abstract class MyConstants {
    public static final String HOUR = "time_hour";
    public static final String MINUTE = "time_minute";
    public static final String TIME_PICKER = "time_picker";
}